javac -cp ".;junit-4.10.jar" SquareRootTestRunner.java
java -cp ".;junit-4.10.jar" SquareRootTestRunner